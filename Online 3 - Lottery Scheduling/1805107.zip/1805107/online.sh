g++ 1805107.c zemaphore.c -o 1805107.o -lpthread
./1805107.o
rm *.o